﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Thesis_project.Forms;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Thesis_project.Forms.LoadTest
{
    [TestClass()]
    public class FormBetoltesLoadTest
    {
        [TestMethod()]
        public void BetoltesLoadTest()
        {
            Assert.Fail();
        }
    }
}